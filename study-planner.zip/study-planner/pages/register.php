<?php
/**
 * pages/register.php
 *
 * Registration page.
 */

require_once __DIR__ . '/../config.php';

if (isLoggedIn()) {
    redirect('/index.php');
}

$errors = [];
$formData = [
    'full_name' => '',
    'email' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Session expired or invalid CSRF token. Please try again.';
    } else {
        $formData['full_name'] = trim($_POST['full_name'] ?? '');
        $formData['email'] = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (strlen($formData['full_name']) < 2) {
            $errors[] = 'Full name should be at least 2 characters long.';
        }

        if (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if (findUserByEmail($formData['email']) !== null) {
            $errors[] = 'That email address is already registered.';
        }

        if (strlen($password) < 8) {
            $errors[] = 'Password should be at least 8 characters long.';
        }
        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = 'Password must include at least one uppercase letter.';
        }
        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = 'Password must include at least one lowercase letter.';
        }
        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = 'Password must include at least one number.';
        }
        if (!preg_match('/[^A-Za-z0-9]/', $password)) {
            $errors[] = 'Password must include at least one special character.';
        }

        if ($password !== $confirmPassword) {
            $errors[] = 'Passwords do not match.';
        }

        if (empty($errors)) {
            $userId = createUser($formData['full_name'], $formData['email'], $password);
            $_SESSION['user_id'] = $userId;

            addFlashMessage('success', 'Account created successfully.');
            redirect('/index.php');
        }
    }
}

$pageTitle = APP_NAME . ' | Register';
$pageHeading = 'Create Account';
$pageDescription = 'Register once to save subjects, plans, preferences, and progress in MySQL.';
$heroEyebrow = 'Account Setup';

require_once __DIR__ . '/../includes/header.php';
?>

<section class="auth-shell">
    <article class="card auth-card">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Register</p>
                <h2>Create your account</h2>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert-stack">
                <?php foreach ($errors as $error): ?>
                    <div class="alert-card alert-danger">
                        <strong>Error:</strong>
                        <span><?= e($error) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" class="form-grid">
            <?= csrfField() ?>
            <div class="input-group full-width">
                <label for="full_name">Full name</label>
                <input
                    id="full_name"
                    name="full_name"
                    type="text"
                    value="<?= e($formData['full_name']) ?>"
                    required
                >
            </div>

            <div class="input-group full-width">
                <label for="email">Email address</label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    value="<?= e($formData['email']) ?>"
                    required
                >
            </div>

            <div class="input-group">
                <label for="password">Password</label>
                <input
                    id="password"
                    name="password"
                    type="password"
                    required
                >
            </div>

            <div class="input-group">
                <label for="confirm_password">Confirm password</label>
                <input
                    id="confirm_password"
                    name="confirm_password"
                    type="password"
                    required
                >
            </div>

            <div class="form-actions full-width">
                <button class="button" type="submit">Create Account</button>
                <a class="button button-secondary" href="<?= e(url('/pages/login.php')) ?>">Back to Login</a>
            </div>
        </form>
    </article>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
