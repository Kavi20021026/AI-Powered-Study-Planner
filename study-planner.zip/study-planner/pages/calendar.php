<?php
/**
 * pages/calendar.php
 *
 * Calendar view of the study plan.
 */

require_once __DIR__ . '/../config.php';
requireLogin();

$month = isset($_GET['month']) ? max(1, min(12, (int) $_GET['month'])) : (int) date('n');
$year = isset($_GET['year']) ? max(2020, min(2100, (int) $_GET['year'])) : (int) date('Y');

$studyPlan = getStudyPlan();
$calendarWeeks = buildCalendarMatrix($studyPlan, $month, $year);
$currentMonth = new DateTime(sprintf('%04d-%02d-01', $year, $month));
$previousMonth = (clone $currentMonth)->modify('-1 month');
$nextMonth = (clone $currentMonth)->modify('+1 month');

$pageTitle = APP_NAME . ' | Calendar';
$pageHeading = 'Calendar View';
$pageDescription = 'See your study plan on a monthly calendar and scan which days already have scheduled tasks.';
$heroEyebrow = 'Calendar';

require_once __DIR__ . '/../includes/header.php';
?>

<section class="card calendar-toolbar">
    <a class="button button-secondary" href="<?= e(url('/pages/calendar.php?month=' . $previousMonth->format('n') . '&year=' . $previousMonth->format('Y'))) ?>">Previous</a>
    <div class="calendar-month-label"><?= e($currentMonth->format('F Y')) ?></div>
    <a class="button button-secondary" href="<?= e(url('/pages/calendar.php?month=' . $nextMonth->format('n') . '&year=' . $nextMonth->format('Y'))) ?>">Next</a>
</section>

<?php if (empty($studyPlan)): ?>
    <article class="card empty-state">
        <h3>No scheduled tasks yet</h3>
        <p>Generate a plan to populate the calendar.</p>
        <a class="button" href="<?= e(url('/pages/generate_plan.php')) ?>">Generate Plan</a>
    </article>
<?php else: ?>
    <section class="card calendar-card">
        <div class="calendar-grid calendar-weekdays">
            <div>Mon</div>
            <div>Tue</div>
            <div>Wed</div>
            <div>Thu</div>
            <div>Fri</div>
            <div>Sat</div>
            <div>Sun</div>
        </div>

        <?php foreach ($calendarWeeks as $week): ?>
            <div class="calendar-grid">
                <?php foreach ($week as $day): ?>
                    <article class="calendar-cell <?= $day['is_current_month'] ? '' : 'is-muted' ?> <?= $day['is_today'] ? 'is-today' : '' ?> <?= !empty($day['tasks']) ? 'has-tasks' : '' ?>"
                             data-date="<?= e(formatFriendlyDate($day['date'])) ?>"
                             data-tasks="<?= jsonForAttribute($day['tasks']) ?>">
                        <div class="calendar-date-row">
                            <strong><?= $day['day_number'] ?></strong>
                            <?php if (!empty($day['tasks'])): ?>
                                <span class="badge badge-neutral"><?= formatHours((float) $day['total_hours']) ?>h</span>
                            <?php endif; ?>
                        </div>

                        <?php if (empty($day['tasks'])): ?>
                            <p class="calendar-empty">No tasks</p>
                        <?php else: ?>
                            <div class="calendar-task-list">
                                <?php foreach (array_slice($day['tasks'], 0, 3) as $task): ?>
                                    <div class="calendar-task">
                                        <strong><?= e($task['subject_name']) ?></strong>
                                        <span><?= formatHours((float) $task['recommended_hours']) ?>h</span>
                                    </div>
                                <?php endforeach; ?>

                                <?php if (count($day['tasks']) > 3): ?>
                                    <p class="calendar-more">+<?= count($day['tasks']) - 3 ?> more</p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </section>
<?php endif; ?>

<div class="modal-overlay" id="calendar-modal" aria-hidden="true" role="dialog">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modal-title">Study Tasks</h3>
            <button class="modal-close" type="button" aria-label="Close modal">&times;</button>
        </div>
        <div class="modal-body" id="modal-body-content">
            <!-- Dynamic task items go here -->
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
