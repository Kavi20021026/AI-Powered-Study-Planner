<?php
/**
 * pages/login.php
 *
 * Login page.
 */

require_once __DIR__ . '/../config.php';

if (isLoggedIn()) {
    redirect('/index.php');
}

$errors = [];
$formData = [
    'email' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Session expired or invalid CSRF token. Please try again.';
    } else {
        $formData['email'] = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if ($password === '') {
            $errors[] = 'Please enter your password.';
        }

        if (empty($errors)) {
            if (attemptLogin($formData['email'], $password)) {
                addFlashMessage('success', 'Welcome back.');
                redirect('/index.php');
            }

            $errors[] = 'Incorrect email or password.';
        }
    }
}

$pageTitle = APP_NAME . ' | Login';
$pageHeading = 'Welcome Back';
$pageDescription = 'Log in to manage your subjects, study plans, and progress.';
$heroEyebrow = 'Account Access';

require_once __DIR__ . '/../includes/header.php';
?>

<section class="auth-shell">
    <article class="card auth-card">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Login</p>
                <h2>Sign in</h2>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert-stack">
                <?php foreach ($errors as $error): ?>
                    <div class="alert-card alert-danger">
                        <strong>Error:</strong>
                        <span><?= e($error) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" class="form-grid">
            <?= csrfField() ?>
            <div class="input-group full-width">
                <label for="email">Email address</label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    value="<?= e($formData['email']) ?>"
                    required
                >
            </div>

            <div class="input-group full-width">
                <label for="password">Password</label>
                <input
                    id="password"
                    name="password"
                    type="password"
                    required
                >
            </div>

            <div class="form-actions full-width">
                <button class="button" type="submit">Login</button>
                <a class="button button-secondary" href="<?= e(url('/pages/register.php')) ?>">Create Account</a>
            </div>
        </form>
    </article>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
