<?php
/**
 * pages/view_plan.php
 *
 * Display the generated plan from MySQL.
 */

require_once __DIR__ . '/../config.php';
requireLogin();

$studyPlan = getStudyPlan();
$groupedPlan = groupPlanByDate($studyPlan);
$overallProgress = getOverallProgress($studyPlan);
$highestPriorityTask = getHighestPriorityTask($studyPlan);

$pageTitle = APP_NAME . ' | View Plan';
$pageHeading = 'View Plan';
$pageDescription = 'Review your day-by-day schedule and move between timeline, calendar, and PDF export views.';
$heroEyebrow = 'Schedule';

require_once __DIR__ . '/../includes/header.php';
?>

<section class="stats-grid">
    <article class="card stat-card">
        <p class="stat-label">Tasks</p>
        <h2><?= count($studyPlan) ?></h2>
        <p class="stat-meta">Study sessions saved in MySQL.</p>
    </article>

    <article class="card stat-card">
        <p class="stat-label">Days</p>
        <h2><?= count($groupedPlan) ?></h2>
        <p class="stat-meta">Dates currently scheduled.</p>
    </article>

    <article class="card stat-card">
        <p class="stat-label">Progress</p>
        <h2><?= $overallProgress ?>%</h2>
        <p class="stat-meta">Completion across the whole plan.</p>
    </article>

    <article class="card stat-card">
        <p class="stat-label">Top Priority</p>
        <h2><?= $highestPriorityTask ? e(number_format((float) $highestPriorityTask['priority_score'], 2)) : '0.00' ?></h2>
        <p class="stat-meta"><?= $highestPriorityTask ? e($highestPriorityTask['subject_name']) : 'No plan yet' ?></p>
    </article>
</section>

<section class="card">
    <div class="card-actions">
        <a class="button" href="<?= e(url('/pages/calendar.php')) ?>">Calendar View</a>
        <a class="button button-secondary" href="<?= e(url('/pages/export_plan.php')) ?>" target="_blank" rel="noopener">Export PDF</a>
    </div>
</section>

<?php if (empty($studyPlan)): ?>
    <article class="card empty-state">
        <h3>No study plan yet</h3>
        <p>Generate a plan to create your schedule.</p>
        <a class="button" href="<?= e(url('/pages/generate_plan.php')) ?>">Generate Plan</a>
    </article>
<?php else: ?>
    <section class="section-block">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Timeline</p>
                <h2>Daily Schedule</h2>
            </div>
            <a class="button button-secondary" href="<?= e(url('/pages/progress.php')) ?>">Update Progress</a>
        </div>

        <div class="schedule-grid">
            <?php foreach ($groupedPlan as $date => $items): ?>
                <?php $dayHours = array_sum(array_column($items, 'recommended_hours')); ?>
                <article class="card schedule-day">
                    <div class="schedule-head">
                        <div>
                            <p class="eyebrow">Study Day</p>
                            <h3><?= e(formatFriendlyDate($date)) ?></h3>
                        </div>
                        <span class="badge badge-neutral"><?= formatHours((float) $dayHours) ?> hrs</span>
                    </div>

                    <div class="timeline">
                        <?php foreach ($items as $item): ?>
                            <div class="timeline-item">
                                <div class="timeline-dot"></div>
                                <div class="timeline-content">
                                    <div class="timeline-top">
                                        <strong><?= e($item['subject_name']) ?></strong>
                                        <span class="badge <?= $item['status'] === 'completed' ? 'badge-success' : 'badge-warning' ?>">
                                            <?= ucfirst(e($item['status'])) ?>
                                        </span>
                                    </div>
                                    <p>
                                        Recommended time: <?= formatHours((float) $item['recommended_hours']) ?> hours<br>
                                        Priority score: <?= e(number_format((float) $item['priority_score'], 2)) ?><br>
                                        Exam date: <?= e(formatFriendlyDate($item['exam_date'])) ?>
                                    </p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
