<?php
/**
 * pages/export_plan.php
 *
 * Print-friendly plan export.
 * Users can save this page as PDF from the browser print dialog.
 */

require_once __DIR__ . '/../config.php';
requireLogin();

$studyPlan = getStudyPlan();
$groupedPlan = groupPlanByDate($studyPlan);
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Plan Export</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; color: #0f172a; }
        h1, h2, h3, p { margin: 0 0 12px; }
        .toolbar { margin-bottom: 24px; }
        .toolbar button { padding: 10px 16px; border: none; background: #2563eb; color: #fff; cursor: pointer; border-radius: 8px; }
        .summary { margin-bottom: 24px; padding: 18px; border: 1px solid #cbd5e1; border-radius: 12px; }
        .day-card { margin-bottom: 20px; border: 1px solid #cbd5e1; border-radius: 12px; padding: 18px; }
        .task { padding: 10px 0; border-top: 1px solid #e2e8f0; }
        .task:first-child { border-top: none; }
        @media print {
            .toolbar { display: none; }
            body { margin: 0; }
        }
    </style>
</head>
<body>
    <div class="toolbar">
        <button type="button" onclick="window.print()">Print / Save as PDF</button>
    </div>

    <section class="summary">
        <h1>AI-Powered Study Planner</h1>
        <p>User: <?= e($user ? $user['full_name'] : 'Student') ?></p>
        <p>Generated: <?= e(date('M d, Y h:i A')) ?></p>
        <p>Total tasks: <?= count($studyPlan) ?></p>
    </section>

    <?php if (empty($studyPlan)): ?>
        <p>No study plan available to export.</p>
    <?php else: ?>
        <?php foreach ($groupedPlan as $date => $items): ?>
            <section class="day-card">
                <h2><?= e(formatFriendlyDate($date)) ?></h2>
                <?php foreach ($items as $item): ?>
                    <div class="task">
                        <h3><?= e($item['subject_name']) ?></h3>
                        <p>Hours: <?= formatHours((float) $item['recommended_hours']) ?></p>
                        <p>Priority score: <?= e(number_format((float) $item['priority_score'], 2)) ?></p>
                        <p>Exam date: <?= e(formatFriendlyDate($item['exam_date'])) ?></p>
                        <p>Status: <?= ucfirst(e($item['status'])) ?></p>
                    </div>
                <?php endforeach; ?>
            </section>
        <?php endforeach; ?>
    <?php endif; ?>

    <script>
        window.setTimeout(() => {
            window.print();
        }, 400);
    </script>
</body>
</html>
