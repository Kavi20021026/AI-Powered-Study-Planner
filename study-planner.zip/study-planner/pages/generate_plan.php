<?php
/**
 * pages/generate_plan.php
 *
 * Generate the study plan from MySQL-backed subjects.
 */

require_once __DIR__ . '/../config.php';
requireLogin();

$subjects = getSubjects();
$studyPlan = getStudyPlan();
$dailyHours = getDailyHours();
$subjectCards = buildSubjectCards($subjects, $studyPlan);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'generate_plan') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? null)) {
        addFlashMessage('danger', 'Session expired or invalid CSRF token. Please try again.');
        redirect('/pages/generate_plan.php');
    }

    if (empty($subjects)) {
        addFlashMessage('danger', 'Please add at least one subject first.');
        redirect('/pages/add_subject.php');
    }

    if ($dailyHours <= 0) {
        addFlashMessage('danger', 'Please save valid daily study hours first.');
        redirect('/index.php');
    }

    generateAndSavePlanForCurrentUser();
    addFlashMessage('success', 'Study plan generated successfully.');
    redirect('/pages/view_plan.php');
}

$pageTitle = APP_NAME . ' | Generate Plan';
$pageHeading = 'Generate Plan';
$pageDescription = 'Preview subject priorities and build a fresh schedule from your stored subjects.';
$heroEyebrow = 'AI Planning';

require_once __DIR__ . '/../includes/header.php';
?>

<section class="card formula-card">
    <div class="section-heading">
        <div>
            <p class="eyebrow">Formula</p>
            <h2>Priority Score</h2>
        </div>
    </div>

    <div class="formula-layout">
        <div class="formula-box">
            <span>Priority Score</span>
            <strong>(Difficulty x <?= APP_WEIGHT ?>) / Days Left</strong>
        </div>

        <div class="formula-notes">
            <p>Easy = 1, Medium = 2, Hard = 3</p>
            <p>Days Left = remaining days until the exam</p>
            <p>Higher scores receive more study time</p>
        </div>
    </div>
</section>

<section class="split-layout">
    <article class="card">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Input</p>
                <h2>Current Settings</h2>
            </div>
        </div>

        <div class="metric-grid">
            <div class="mini-stat">
                <span>Subjects</span>
                <strong><?= count($subjects) ?></strong>
            </div>
            <div class="mini-stat">
                <span>Daily Hours</span>
                <strong><?= formatHours($dailyHours) ?></strong>
            </div>
            <div class="mini-stat">
                <span>Stored Tasks</span>
                <strong><?= count($studyPlan) ?></strong>
            </div>
        </div>

        <form method="post">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="generate_plan">
            <button
                class="button"
                type="submit"
                data-confirm-generate
                data-has-plan="<?= empty($studyPlan) ? 'false' : 'true' ?>"
            >
                <?= empty($studyPlan) ? 'Generate Study Plan' : 'Regenerate Study Plan' ?>
            </button>
        </form>
    </article>

    <article class="card">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Result</p>
                <h2>What Happens Next</h2>
            </div>
        </div>

        <div class="info-list">
            <div class="info-item">
                <strong>Subjects are ranked</strong>
                <p>Difficulty and exam urgency are combined into one score.</p>
            </div>
            <div class="info-item">
                <strong>Hours are distributed</strong>
                <p>Your saved daily study time is shared across active subjects.</p>
            </div>
            <div class="info-item">
                <strong>Plan is stored in MySQL</strong>
                <p>The generated schedule becomes available in view, progress, calendar, and export pages.</p>
            </div>
        </div>
    </article>
</section>

<section class="section-block">
    <div class="section-heading">
        <div>
            <p class="eyebrow">Preview</p>
            <h2>Subject Priority Table</h2>
        </div>
    </div>

    <?php if (empty($subjectCards)): ?>
        <article class="card empty-state">
            <h3>No subjects available</h3>
            <p>Add subjects first to generate a plan.</p>
            <a class="button" href="<?= e(url('/pages/add_subject.php')) ?>">Add Subject</a>
        </article>
    <?php else: ?>
        <div class="card table-card">
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Difficulty</th>
                            <th>Value</th>
                            <th>Days Left</th>
                            <th>Priority Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($subjectCards as $subject): ?>
                            <tr>
                                <td><?= e($subject['name']) ?></td>
                                <td><?= e($subject['difficulty_label']) ?></td>
                                <td><?= $subject['difficulty_value'] ?></td>
                                <td><?= $subject['days_left'] === 0 ? 'Past' : $subject['days_left'] ?></td>
                                <td><?= e(number_format((float) $subject['priority_score'], 2)) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
