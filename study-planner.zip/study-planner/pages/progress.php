<?php
/**
 * pages/progress.php
 *
 * Update task completion and track progress.
 */

require_once __DIR__ . '/../config.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_status') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? null)) {
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
            exit;
        }
        addFlashMessage('danger', 'Session expired or invalid CSRF token. Please try again.');
        redirect('/pages/progress.php');
    }

    $planId = isset($_POST['plan_id']) ? (int) $_POST['plan_id'] : 0;
    $status = $_POST['status'] ?? 'pending';

    $success = $planId > 0 && updateStudyPlanStatus($planId, $status);

    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        $studyPlan = getStudyPlan();
        $completedTasks = count(array_filter($studyPlan, function (array $planItem): bool {
            return $planItem['status'] === 'completed';
        }));
        echo json_encode([
            'success' => $success,
            'overall_progress' => getOverallProgress($studyPlan),
            'completed_tasks' => $completedTasks,
            'total_tasks' => count($studyPlan),
            'pending_tasks' => count($studyPlan) - $completedTasks,
            'subject_progress' => array_map(function ($subject) use ($studyPlan) {
                $summary = getSubjectProgressSummary($subject, $studyPlan);
                return [
                    'id' => $subject['id'],
                    'progress_percentage' => $summary['progress_percentage'],
                    'completed_hours' => formatHours((float) $summary['completed_hours']),
                    'remaining_hours' => formatHours((float) $summary['remaining_hours'])
                ];
            }, getSubjects())
        ]);
        exit;
    }

    if ($success) {
        addFlashMessage('success', 'Task status updated successfully.');
    } else {
        addFlashMessage('danger', 'Unable to update that task.');
    }

    redirect('/pages/progress.php');
}

$subjects = getSubjects();
$studyPlan = getStudyPlan();
$subjectCards = buildSubjectCards($subjects, $studyPlan);
$overallProgress = getOverallProgress($studyPlan);
$pendingTasks = array_values(array_filter($studyPlan, function (array $planItem): bool {
    return $planItem['status'] === 'pending';
}));
$completedTasks = array_values(array_filter($studyPlan, function (array $planItem): bool {
    return $planItem['status'] === 'completed';
}));

$pageTitle = APP_NAME . ' | Progress';
$pageHeading = 'Progress';
$pageDescription = 'Track subject completion, mark tasks done, and keep the latest progress synced to the database.';
$heroEyebrow = 'Tracking';

require_once __DIR__ . '/../includes/header.php';
?>

<section class="split-layout">
    <article class="card progress-ring-stat">
        <div class="progress-ring-container large-progress-ring" style="--progress-percent: <?= $overallProgress ?>;">
            <svg class="progress-ring" width="120" height="120">
                <circle class="progress-ring-bg" stroke="var(--border)" stroke-width="8" fill="transparent" r="50" cx="60" cy="60"/>
                <circle class="progress-ring-bar" stroke="var(--accent)" stroke-width="8" fill="transparent" r="50" cx="60" cy="60"/>
            </svg>
            <div class="progress-ring-text">
                <h3 id="overall-progress-text"><?= $overallProgress ?>%</h3>
            </div>
        </div>
        <div>
            <p class="eyebrow">Overall</p>
            <h2>Progress Status</h2>
            <p class="stat-meta">Completion track for all your scheduled topics.</p>
        </div>
    </article>

    <article class="card">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Summary</p>
                <h2>Task Counts</h2>
            </div>
        </div>

        <div class="metric-grid">
            <div class="mini-stat">
                <span>Pending</span>
                <strong><?= count($pendingTasks) ?></strong>
            </div>
            <div class="mini-stat">
                <span>Completed</span>
                <strong><?= count($completedTasks) ?></strong>
            </div>
            <div class="mini-stat">
                <span>Subjects</span>
                <strong><?= count($subjects) ?></strong>
            </div>
        </div>
    </article>
</section>

<section class="section-block">
    <div class="section-heading">
        <div>
            <p class="eyebrow">By Subject</p>
            <h2>Progress Breakdown</h2>
        </div>
    </div>

    <?php if (empty($subjectCards)): ?>
        <article class="card empty-state">
            <h3>No subjects available</h3>
            <p>Add subjects and generate a plan before tracking progress.</p>
        </article>
    <?php else: ?>
        <div class="subject-grid">
            <?php foreach ($subjectCards as $subject): ?>
                <article class="card subject-card" data-subject-progress-id="<?= $subject['id'] ?>">
                    <div class="subject-card-top">
                        <div>
                            <p class="eyebrow">Progress</p>
                            <h3><?= e($subject['name']) ?></h3>
                        </div>
                        <span class="badge badge-neutral progress-badge"><?= $subject['progress']['progress_percentage'] ?>%</span>
                    </div>

                    <div class="progress-block">
                        <div class="progress-head">
                            <span>Completion</span>
                            <strong class="progress-text"><?= $subject['progress']['progress_percentage'] ?>%</strong>
                        </div>
                        <div class="progress-track">
                            <div class="progress-fill" style="width: <?= $subject['progress']['progress_percentage'] ?>%"></div>
                        </div>
                    </div>

                    <div class="metric-row">
                        <div>
                            <p class="mini-label">Completed</p>
                            <strong class="completed-hours-val"><?= formatHours((float) $subject['progress']['completed_hours']) ?> hrs</strong>
                        </div>
                        <div>
                            <p class="mini-label">Remaining</p>
                            <strong class="remaining-hours-val"><?= formatHours((float) $subject['progress']['remaining_hours']) ?> hrs</strong>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<section class="split-layout">
    <article class="card">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Pending</p>
                <h2>Mark Complete</h2>
            </div>
        </div>

        <?php if (empty($pendingTasks)): ?>
            <div class="empty-inline">
                <p>No pending tasks right now.</p>
            </div>
        <?php else: ?>
            <div class="list-stack" data-pending-tasks-list>
                <?php foreach ($pendingTasks as $task): ?>
                    <div class="list-card task-card" data-task-plan-id="<?= $task['id'] ?>">
                        <div class="task-details">
                            <strong><?= e($task['subject_name']) ?></strong>
                            <p><?= e(formatFriendlyDate($task['date'])) ?> | <?= formatHours((float) $task['recommended_hours']) ?> hrs</p>
                            <?php if (!empty($task['subject_notes'])): ?>
                                <p class="task-notes"><strong>Notes:</strong> <?= nl2br(e($task['subject_notes'])) ?></p>
                            <?php endif; ?>
                        </div>

                        <form method="post" class="status-form">
                            <?= csrfField() ?>
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="plan_id" value="<?= $task['id'] ?>">
                            <input type="hidden" name="status" value="completed">
                            <button class="button" type="submit">Mark Complete</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </article>

    <article class="card">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Completed</p>
                <h2>Move Back</h2>
            </div>
        </div>

        <?php if (empty($completedTasks)): ?>
            <div class="empty-inline">
                <p>Completed tasks will appear here once you start updating progress.</p>
            </div>
        <?php else: ?>
            <div class="list-stack" data-completed-tasks-list>
                <?php foreach ($completedTasks as $task): ?>
                    <div class="list-card task-card" data-task-plan-id="<?= $task['id'] ?>">
                        <div class="task-details">
                            <strong><?= e($task['subject_name']) ?></strong>
                            <p><?= e(formatFriendlyDate($task['date'])) ?> | <?= formatHours((float) $task['recommended_hours']) ?> hrs</p>
                            <?php if (!empty($task['subject_notes'])): ?>
                                <p class="task-notes"><strong>Notes:</strong> <?= nl2br(e($task['subject_notes'])) ?></p>
                            <?php endif; ?>
                        </div>

                        <form method="post" class="status-form">
                            <?= csrfField() ?>
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="plan_id" value="<?= $task['id'] ?>">
                            <input type="hidden" name="status" value="pending">
                            <button class="button button-secondary" type="submit">Mark Pending</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </article>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
