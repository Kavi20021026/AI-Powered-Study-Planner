<?php
/**
 * pages/edit_subject.php
 *
 * Edit an existing subject.
 */

require_once __DIR__ . '/../config.php';
requireLogin();

$subjectId = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$subject = $subjectId > 0 ? getSubjectById($subjectId) : null;

if ($subject === null) {
    addFlashMessage('danger', 'Subject not found.');
    redirect('/index.php');
}

$errors = [];
$formData = [
    'name' => $subject['name'],
    'difficulty' => $subject['difficulty'],
    'exam_date' => $subject['exam_date'],
    'subject_notes' => $subject['subject_notes'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Session expired or invalid CSRF token. Please try again.';
    } else {
        $formData['name'] = trim($_POST['name'] ?? '');
        $formData['difficulty'] = normalizeDifficulty($_POST['difficulty'] ?? 'medium');
        $formData['exam_date'] = $_POST['exam_date'] ?? '';
        $formData['subject_notes'] = $_POST['subject_notes'] ?? '';

        if (strlen($formData['name']) < 2) {
            $errors[] = 'Subject name should be at least 2 characters long.';
        }

        if (!$formData['exam_date']) {
            $errors[] = 'Please choose an exam date.';
        } elseif ($formData['exam_date'] < date('Y-m-d')) {
            $errors[] = 'Exam date cannot be in the past.';
        }

        if (empty($errors)) {
            updateSubjectRecord($subjectId, $formData);
            addFlashMessage('success', 'Subject updated successfully.');
            redirect('/index.php');
        }
    }
}

$pageTitle = APP_NAME . ' | Edit Subject';
$pageHeading = 'Edit Subject';
$pageDescription = 'Update the subject details and keep your plan aligned with the latest exam date.';
$heroEyebrow = 'Subject Management';

require_once __DIR__ . '/../includes/header.php';
?>

<section class="card">
    <div class="section-heading">
        <div>
            <p class="eyebrow">Update</p>
            <h2><?= e($subject['name']) ?></h2>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert-stack">
            <?php foreach ($errors as $error): ?>
                <div class="alert-card alert-danger">
                    <strong>Error:</strong>
                    <span><?= e($error) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" class="form-grid" data-subject-form novalidate>
        <?= csrfField() ?>
        <div class="input-group full-width">
            <label for="name">Subject name</label>
            <input
                id="name"
                name="name"
                type="text"
                value="<?= e($formData['name']) ?>"
                required
            >
        </div>

        <div class="input-group">
            <label for="difficulty">Difficulty</label>
            <select id="difficulty" name="difficulty" required>
                <option value="easy" <?= $formData['difficulty'] === 'easy' ? 'selected' : '' ?>>Easy (1)</option>
                <option value="medium" <?= $formData['difficulty'] === 'medium' ? 'selected' : '' ?>>Medium (2)</option>
                <option value="hard" <?= $formData['difficulty'] === 'hard' ? 'selected' : '' ?>>Hard (3)</option>
            </select>
        </div>

        <div class="input-group">
            <label for="exam_date">Exam date</label>
            <input
                id="exam_date"
                name="exam_date"
                type="date"
                value="<?= e($formData['exam_date']) ?>"
                data-exam-date
                required
            >
        </div>

        <div class="input-group full-width">
            <label for="subject_notes">Subject notes / Checklist / Resources</label>
            <textarea
                id="subject_notes"
                name="subject_notes"
                rows="4"
                placeholder="Textbook sections, study links, notes..."
            ><?= e($formData['subject_notes']) ?></textarea>
        </div>

        <div class="form-actions full-width">
            <button class="button" type="submit">Update Subject</button>
            <a class="button button-secondary" href="<?= e(url('/index.php')) ?>">Cancel</a>
        </div>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
