<?php
/**
 * pages/logout.php
 *
 * End the current login session.
 */

require_once __DIR__ . '/../config.php';

logoutCurrentUser();
addFlashMessage('success', 'You have been logged out.');
redirect('/pages/login.php');
