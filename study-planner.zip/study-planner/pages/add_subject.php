<?php
/**
 * pages/add_subject.php
 *
 * Add a subject for the logged-in user.
 */

require_once __DIR__ . '/../config.php';
requireLogin();

$errors = [];
$formData = [
    'name' => '',
    'difficulty' => 'medium',
    'exam_date' => date('Y-m-d', strtotime('+7 days')),
    'subject_notes' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Session expired or invalid CSRF token. Please try again.';
    } else {
        $formData['name'] = trim($_POST['name'] ?? '');
        $formData['difficulty'] = normalizeDifficulty($_POST['difficulty'] ?? 'medium');
        $formData['exam_date'] = $_POST['exam_date'] ?? '';
        $formData['subject_notes'] = $_POST['subject_notes'] ?? '';

        if (strlen($formData['name']) < 2) {
            $errors[] = 'Subject name should be at least 2 characters long.';
        }

        if (!$formData['exam_date']) {
            $errors[] = 'Please choose an exam date.';
        } elseif ($formData['exam_date'] < date('Y-m-d')) {
            $errors[] = 'Exam date cannot be in the past.';
        }

        if (empty($errors)) {
            addSubjectToStore($formData);
            addFlashMessage('success', 'Subject added successfully.');
            redirect('/index.php');
        }
    }
}

$recentSubjects = array_slice(getSubjects(), 0, 6);

$pageTitle = APP_NAME . ' | Add Subject';
$pageHeading = 'Add Subject';
$pageDescription = 'Create a new subject and save it directly to your account.';
$heroEyebrow = 'Subject Management';

require_once __DIR__ . '/../includes/header.php';
?>

<section class="split-layout">
    <article class="card">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Create</p>
                <h2>New Subject</h2>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert-stack">
                <?php foreach ($errors as $error): ?>
                    <div class="alert-card alert-danger">
                        <strong>Error:</strong>
                        <span><?= e($error) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" class="form-grid" data-subject-form novalidate>
            <?= csrfField() ?>
            <div class="input-group full-width">
                <label for="name">Subject name</label>
                <input
                    id="name"
                    name="name"
                    type="text"
                    placeholder="Example: Database Systems"
                    value="<?= e($formData['name']) ?>"
                    required
                >
            </div>

            <div class="input-group">
                <label for="difficulty">Difficulty</label>
                <select id="difficulty" name="difficulty" required>
                    <option value="easy" <?= $formData['difficulty'] === 'easy' ? 'selected' : '' ?>>Easy (1)</option>
                    <option value="medium" <?= $formData['difficulty'] === 'medium' ? 'selected' : '' ?>>Medium (2)</option>
                    <option value="hard" <?= $formData['difficulty'] === 'hard' ? 'selected' : '' ?>>Hard (3)</option>
                </select>
            </div>

            <div class="input-group">
                <label for="exam_date">Exam date</label>
                <input
                    id="exam_date"
                    name="exam_date"
                    type="date"
                    value="<?= e($formData['exam_date']) ?>"
                    data-exam-date
                    required
                >
            </div>

            <div class="input-group full-width">
                <label for="subject_notes">Subject notes / Checklist / Resources</label>
                <textarea
                    id="subject_notes"
                    name="subject_notes"
                    rows="4"
                    placeholder="Textbook sections, study links, notes..."
                ><?= e($formData['subject_notes']) ?></textarea>
            </div>

            <div class="form-actions full-width">
                <button class="button" type="submit">Save Subject</button>
                <a class="button button-secondary" href="<?= e(url('/index.php')) ?>">Back to Dashboard</a>
            </div>
        </form>
    </article>

    <article class="card">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Recent</p>
                <h2>Latest Subjects</h2>
            </div>
        </div>

        <?php if (empty($recentSubjects)): ?>
            <div class="empty-inline">
                <p>No subjects saved yet.</p>
            </div>
        <?php else: ?>
            <div class="list-stack">
                <?php foreach ($recentSubjects as $subject): ?>
                    <div class="list-card">
                        <div>
                            <strong><?= e($subject['name']) ?></strong>
                            <p><?= e(difficultyToLabel($subject['difficulty'])) ?> | <?= e(formatFriendlyDate($subject['exam_date'])) ?></p>
                        </div>
                        <span class="badge badge-neutral"><?= difficultyToNumber($subject['difficulty']) ?>/3</span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </article>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
