/**
 * js/app.js
 *
 * This file adds small frontend interactions:
 * - dark mode toggle
 * - form validation helpers
 * - flash message closing
 * - confirmation before regenerating the plan
 */

document.addEventListener("DOMContentLoaded", () => {
    const html = document.documentElement;
    const themeToggle = document.querySelector("[data-theme-toggle]");
    const themeLabel = document.querySelector("[data-theme-label]");
    const navToggle = document.querySelector("[data-nav-toggle]");
    const navigation = document.querySelector(".nav-links");
    const savedTheme = localStorage.getItem("studyPlannerTheme");

    /**
     * Apply a theme to the root HTML element and update the button label.
     */
    function setTheme(theme) {
        html.setAttribute("data-theme", theme);

        if (themeLabel) {
            themeLabel.textContent = theme === "dark" ? "Light mode" : "Dark mode";
        }
    }

    // Load the last selected theme, or follow the user's system preference.
    if (savedTheme) {
        setTheme(savedTheme);
    } else if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
        setTheme("dark");
    } else {
        setTheme("light");
    }

    if (themeToggle) {
        themeToggle.addEventListener("click", () => {
            const nextTheme = html.getAttribute("data-theme") === "dark" ? "light" : "dark";
            setTheme(nextTheme);
            localStorage.setItem("studyPlannerTheme", nextTheme);
        });
    }

    /**
     * Toggle the mobile navigation panel.
     */
    function setNavigationState(isOpen) {
        if (!navToggle || !navigation) {
            return;
        }

        navigation.classList.toggle("is-open", isOpen);
        navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    }

    if (navToggle && navigation) {
        navToggle.addEventListener("click", () => {
            const isOpen = navigation.classList.contains("is-open");
            setNavigationState(!isOpen);
        });

        navigation.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth <= 720) {
                    setNavigationState(false);
                }
            });
        });

        window.addEventListener("resize", () => {
            if (window.innerWidth > 720) {
                setNavigationState(false);
            }
        });
    }

    /**
     * Confirm before deleting a subject.
     */
    document.querySelectorAll("[data-confirm-delete]").forEach((button) => {
        button.addEventListener("click", (event) => {
            const confirmed = window.confirm("Delete this subject and refresh the study plan?");

            if (!confirmed) {
                event.preventDefault();
            }
        });
    });

    // Allow the user to manually close flash messages.
    document.querySelectorAll("[data-close-flash]").forEach((button) => {
        button.addEventListener("click", () => {
            const flash = button.closest(".flash");

            if (flash) {
                flash.classList.add("is-hidden");
                window.setTimeout(() => flash.remove(), 220);
            }
        });
    });

    // Also auto-dismiss temporary flash messages after a short delay.
    document.querySelectorAll("[data-auto-dismiss='true']").forEach((flash, index) => {
        window.setTimeout(() => {
            flash.classList.add("is-hidden");
            window.setTimeout(() => flash.remove(), 220);
        }, 4000 + index * 350);
    });

    /**
     * Browser reminder support.
     */
    const reminderPayloadElement = document.querySelector("[data-reminder-payload]");
    const notificationStatus = document.querySelector("[data-notification-status]");
    const notificationButton = document.querySelector("[data-request-notifications]");

    function updateNotificationStatus() {
        if (!notificationStatus) {
            return;
        }

        if (!("Notification" in window)) {
            notificationStatus.textContent = "Browser notifications are not supported in this browser.";
            return;
        }

        if (Notification.permission === "granted") {
            notificationStatus.textContent = "Browser notifications are enabled.";
        } else if (Notification.permission === "denied") {
            notificationStatus.textContent = "Browser notifications are blocked in this browser.";
        } else {
            notificationStatus.textContent = "Browser notifications are not enabled yet.";
        }
    }

    if (notificationButton) {
        notificationButton.addEventListener("click", async () => {
            if (!("Notification" in window)) {
                window.alert("This browser does not support notifications.");
                return;
            }

            const permission = await Notification.requestPermission();
            updateNotificationStatus();

            if (permission === "granted") {
                new Notification("Study Planner", {
                    body: "Browser reminders are ready.",
                });
            }
        });
    }

    updateNotificationStatus();

    if (reminderPayloadElement && "Notification" in window && Notification.permission === "granted") {
        try {
            const payload = JSON.parse(reminderPayloadElement.getAttribute("data-reminder-payload") || "{}");
            const now = new Date();
            const reminderTime = String(payload.reminder_time || "18:00").split(":");
            const reminderHour = Number(reminderTime[0] || 18);
            const reminderMinute = Number(reminderTime[1] || 0);
            const shouldNotifyNow =
                Boolean(payload.enabled) &&
                (now.getHours() > reminderHour || (now.getHours() === reminderHour && now.getMinutes() >= reminderMinute));

            const cacheKey = `studyPlannerReminder_${payload.user_id}_${now.toISOString().split("T")[0]}`;

            if (shouldNotifyNow && !localStorage.getItem(cacheKey)) {
                const nextTask = payload.today_tasks?.[0];
                const urgentSubject = payload.urgent_subjects?.[0];
                let body = "No tasks scheduled for today.";

                if (nextTask) {
                    body = `${nextTask.subject_name}: ${nextTask.recommended_hours} hrs today.`;
                } else if (urgentSubject) {
                    body = `${urgentSubject.name} exam is in ${urgentSubject.days_left} day(s).`;
                }

                new Notification("Study Planner Reminder", { body });
                localStorage.setItem(cacheKey, "shown");
            }
        } catch (error) {
            console.error("Reminder payload error", error);
        }
    }

    // Prevent the exam date from being earlier than today.
    document.querySelectorAll("[data-exam-date]").forEach((input) => {
        const today = new Date().toISOString().split("T")[0];
        input.setAttribute("min", today);
    });

    /**
     * Basic validation for the add subject form.
     * This is frontend validation only. PHP still validates again on the server.
     */
    const subjectForm = document.querySelector("[data-subject-form]");

    if (subjectForm) {
        subjectForm.addEventListener("submit", (event) => {
            const nameInput = subjectForm.querySelector("#name");
            const dateInput = subjectForm.querySelector("#exam_date");

            if (!nameInput || !dateInput) {
                return;
            }

            const subjectName = nameInput.value.trim();
            const examDate = dateInput.value;
            const today = new Date().toISOString().split("T")[0];

            if (subjectName.length < 2) {
                event.preventDefault();
                window.alert("Please enter a subject name with at least 2 characters.");
                nameInput.focus();
                return;
            }

            if (!examDate || examDate < today) {
                event.preventDefault();
                window.alert("Please choose a valid exam date that is today or later.");
                dateInput.focus();
            }
        });
    }

    /**
     * Basic validation for the daily hours input.
     */
    const hoursForm = document.querySelector("[data-hours-form]");

    if (hoursForm) {
        hoursForm.addEventListener("submit", (event) => {
            const hoursInput = hoursForm.querySelector("#daily_hours");
            const hoursValue = Number(hoursInput?.value ?? 0);

            if (hoursValue < 0.5 || hoursValue > 16) {
                event.preventDefault();
                window.alert("Daily study hours must be between 0.5 and 16.");
                hoursInput?.focus();
            }
        });
    }

    /**
     * Ask for confirmation before overwriting the current study plan.
     */
    const generateButton = document.querySelector("[data-confirm-generate]");

    if (generateButton) {
        generateButton.addEventListener("click", (event) => {
            const alreadyHasPlan = generateButton.getAttribute("data-has-plan") === "true";

            if (alreadyHasPlan) {
                const confirmed = window.confirm("A plan already exists. Do you want to regenerate it?");

                if (!confirmed) {
                    event.preventDefault();
                }
            }
        });
    }

    // Exam countdown timer
    const countdownEl = document.querySelector(".countdown-widget");
    if (countdownEl) {
        const targetStr = countdownEl.getAttribute("data-countdown-target") || "";
        let targetDate = 0;

        try {
            const parts = targetStr.trim().split(/[\sT]+/);
            const dateParts = parts[0].split("-");
            const timeParts = (parts[1] || "09:00:00").split(":");

            const year = parseInt(dateParts[0], 10);
            const month = parseInt(dateParts[1], 10) - 1;
            const day = parseInt(dateParts[2], 10);

            const hour = parseInt(timeParts[0], 10);
            const minute = parseInt(timeParts[1], 10);
            const second = parseInt(timeParts[2], 10);

            targetDate = new Date(year, month, day, hour, minute, second).getTime();
        } catch (e) {
            console.error("Countdown date parsing error", e);
        }

        function updateCountdown() {
            const now = new Date().getTime();
            const difference = targetDate - now;

            if (difference < 0) {
                countdownEl.innerHTML = "<p class='countdown-label'>Exam in progress or completed!</p>";
                return;
            }

            const days = Math.floor(difference / (1000 * 60 * 60 * 24));
            const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((difference % (1000 * 60)) / 1000);

            const dEl = document.getElementById("cd-days");
            const hEl = document.getElementById("cd-hours");
            const mEl = document.getElementById("cd-mins");
            const sEl = document.getElementById("cd-secs");

            if (dEl) dEl.textContent = String(days).padStart(2, "0");
            if (hEl) hEl.textContent = String(hours).padStart(2, "0");
            if (mEl) mEl.textContent = String(minutes).padStart(2, "0");
            if (sEl) sEl.textContent = String(seconds).padStart(2, "0");
        }

        updateCountdown();
        window.setInterval(updateCountdown, 1000);
    }

    // Calendar Modal handling
    const calendarModal = document.getElementById("calendar-modal");
    if (calendarModal) {
        const modalTitle = document.getElementById("modal-title");
        const modalBody = document.getElementById("modal-body-content");
        const modalClose = calendarModal.querySelector(".modal-close");

        document.querySelectorAll(".calendar-cell").forEach((cell) => {
            cell.addEventListener("click", () => {
                const tasksData = cell.getAttribute("data-tasks");
                if (!tasksData) return;

                const dateStr = cell.getAttribute("data-date");
                const tasks = JSON.parse(tasksData || "[]");

                modalTitle.textContent = `Schedule for ${dateStr}`;

                if (tasks.length === 0) {
                    modalBody.innerHTML = "<p>No study tasks scheduled for this day.</p>";
                } else {
                    let html = '<div class="modal-task-list">';
                    tasks.forEach((task) => {
                        const statusClass = task.status === 'completed' ? 'badge-success' : 'badge-warning';
                        const notesHTML = task.subject_notes ? `<p class="modal-task-notes"><strong>Notes:</strong> ${task.subject_notes.replace(/\n/g, '<br>')}</p>` : '';
                        html += `
                            <div class="modal-task-item">
                                <div class="modal-task-header">
                                    <strong>${task.subject_name}</strong>
                                    <span class="badge ${statusClass}">${task.status.charAt(0).toUpperCase() + task.status.slice(1)}</span>
                                </div>
                                <p>Recommended Time: <strong>${parseFloat(task.recommended_hours).toFixed(1)} hrs</strong></p>
                                <p>Exam Date: ${task.exam_date}</p>
                                ${notesHTML}
                            </div>
                        `;
                    });
                    html += '</div>';
                    modalBody.innerHTML = html;
                }

                calendarModal.classList.add("is-visible");
                calendarModal.setAttribute("aria-hidden", "false");
            });
        });

        function closeModal() {
            calendarModal.classList.remove("is-visible");
            calendarModal.setAttribute("aria-hidden", "true");
        }

        if (modalClose) {
            modalClose.addEventListener("click", (e) => {
                e.stopPropagation();
                closeModal();
            });
        }

        calendarModal.addEventListener("click", (e) => {
            if (e.target === calendarModal) {
                closeModal();
            }
        });

        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape" && calendarModal.classList.contains("is-visible")) {
                closeModal();
            }
        });
    }

    // AJAX progress status toggles
    const progressPage = document.querySelector("[data-pending-tasks-list], [data-completed-tasks-list]");
    if (progressPage) {
        document.addEventListener("submit", async (event) => {
            const form = event.target;
            if (!form.classList.contains("status-form")) return;

            event.preventDefault();

            const formData = new FormData(form);
            const status = formData.get("status");

            try {
                const response = await fetch(window.location.href, {
                    method: "POST",
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    body: formData
                });

                if (!response.ok) throw new Error("HTTP error " + response.status);

                const data = await response.json();
                if (data.success) {
                    // Update overall progress text and SVG ring
                    const progressText = document.getElementById("overall-progress-text");
                    const progressRing = document.querySelector(".large-progress-ring");
                    if (progressText) progressText.textContent = data.overall_progress + "%";
                    if (progressRing) {
                        progressRing.style.setProperty("--progress-percent", data.overall_progress);
                    }

                    // Update task counters in Summary card
                    const counters = document.querySelectorAll(".mini-stat strong");
                    if (counters.length >= 2) {
                        counters[0].textContent = data.pending_tasks;
                        counters[1].textContent = data.completed_tasks;
                    }

                    // Move task card to the other stack
                    const taskCard = form.closest(".task-card");
                    if (taskCard) {
                        const nextStatus = status === "completed" ? "pending" : "completed";
                        const newButtonText = status === "completed" ? "Mark Pending" : "Mark Complete";
                        const newButtonClass = status === "completed" ? "button button-secondary" : "button";

                        form.querySelector("input[name='status']").value = nextStatus;
                        const button = form.querySelector("button");
                        button.textContent = newButtonText;
                        button.className = newButtonClass;

                        const pendingList = document.querySelector("[data-pending-tasks-list]");
                        const completedList = document.querySelector("[data-completed-tasks-list]");

                        taskCard.remove();

                        if (status === "completed") {
                            if (completedList) {
                                const emptyInline = completedList.querySelector(".empty-inline") || completedList.parentElement.querySelector(".empty-inline");
                                if (emptyInline) emptyInline.remove();
                                completedList.appendChild(taskCard);
                            }
                        } else {
                            if (pendingList) {
                                const emptyInline = pendingList.querySelector(".empty-inline") || pendingList.parentElement.querySelector(".empty-inline");
                                if (emptyInline) emptyInline.remove();
                                pendingList.appendChild(taskCard);
                            }
                        }

                        // Check if either list became empty and show fallback labels
                        const pendingStack = document.querySelector("[data-pending-tasks-list]");
                        const completedStack = document.querySelector("[data-completed-tasks-list]");

                        if (pendingStack && pendingStack.children.length === 0) {
                            const parent = pendingStack.parentElement;
                            if (!parent.querySelector(".empty-inline")) {
                                const emptyDiv = document.createElement("div");
                                emptyDiv.className = "empty-inline";
                                emptyDiv.innerHTML = "<p>No pending tasks right now.</p>";
                                parent.appendChild(emptyDiv);
                            }
                        }
                        if (completedStack && completedStack.children.length === 0) {
                            const parent = completedStack.parentElement;
                            if (!parent.querySelector(".empty-inline")) {
                                const emptyDiv = document.createElement("div");
                                emptyDiv.className = "empty-inline";
                                emptyDiv.innerHTML = "<p>Completed tasks will appear here once you start updating progress.</p>";
                                parent.appendChild(emptyDiv);
                            }
                        }
                    }

                    // Update individual subject cards progress stats
                    if (data.subject_progress) {
                        data.subject_progress.forEach((sub) => {
                            const card = document.querySelector(`[data-subject-progress-id='${sub.id}']`);
                            if (card) {
                                const progressBadge = card.querySelector(".progress-badge");
                                const subProgressText = card.querySelector(".progress-text");
                                const progressFill = card.querySelector(".progress-fill");
                                const completedHoursVal = card.querySelector(".completed-hours-val");
                                const remainingHoursVal = card.querySelector(".remaining-hours-val");

                                if (progressBadge) progressBadge.textContent = sub.progress_percentage + "%";
                                if (subProgressText) subProgressText.textContent = sub.progress_percentage + "%";
                                if (progressFill) progressFill.style.width = sub.progress_percentage + "%";
                                if (completedHoursVal) completedHoursVal.textContent = sub.completed_hours + " hrs";
                                if (remainingHoursVal) remainingHoursVal.textContent = sub.remaining_hours + " hrs";
                            }
                        });
                    }
                } else {
                    window.alert("Error: " + (data.error || "Unable to update status."));
                }
            } catch (error) {
                console.error("AJAX Error:", error);
                window.alert("Network error: Could not complete operation.");
            }
        });
    }
});
