<?php
/**
 * includes/functions.php
 *
 * Shared database, auth, and planner helpers.
 */

function initializeAppState(): void
{
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = [];
    }

    $connection = getDbConnection();
    runDatabaseMigrations($connection);
}

function getDbConnection(): mysqli
{
    static $connection = null;

    if ($connection instanceof mysqli) {
        return $connection;
    }

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    $connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $connection->set_charset('utf8mb4');

    return $connection;
}

function runDatabaseMigrations(mysqli $connection): void
{
    static $hasRun = false;

    if ($hasRun) {
        return;
    }

    $connection->query(
        "CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(120) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            daily_study_hours DECIMAL(4,1) NOT NULL DEFAULT 4.0,
            browser_reminders_enabled TINYINT(1) NOT NULL DEFAULT 0,
            reminder_time TIME NOT NULL DEFAULT '18:00:00',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    $connection->query(
        "CREATE TABLE IF NOT EXISTS subjects (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            subject_name VARCHAR(120) NOT NULL,
            difficulty ENUM('easy', 'medium', 'hard') NOT NULL,
            difficulty_value TINYINT UNSIGNED NOT NULL,
            exam_date DATE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_subjects_user
                FOREIGN KEY (user_id) REFERENCES users(id)
                ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    $connection->query(
        "CREATE TABLE IF NOT EXISTS study_plan (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            subject_id INT UNSIGNED NOT NULL,
            plan_date DATE NOT NULL,
            days_left INT UNSIGNED NOT NULL,
            priority_score DECIMAL(10, 2) NOT NULL,
            recommended_hours DECIMAL(5, 2) NOT NULL,
            status ENUM('pending', 'completed') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            CONSTRAINT fk_study_plan_user
                FOREIGN KEY (user_id) REFERENCES users(id)
                ON DELETE CASCADE,
            CONSTRAINT fk_study_plan_subject
                FOREIGN KEY (subject_id) REFERENCES subjects(id)
                ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    ensureColumnExists(
        $connection,
        'users',
        'daily_study_hours',
        "ALTER TABLE users ADD COLUMN daily_study_hours DECIMAL(4,1) NOT NULL DEFAULT 4.0 AFTER password_hash"
    );

    ensureColumnExists(
        $connection,
        'users',
        'browser_reminders_enabled',
        "ALTER TABLE users ADD COLUMN browser_reminders_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER daily_study_hours"
    );

    ensureColumnExists(
        $connection,
        'users',
        'reminder_time',
        "ALTER TABLE users ADD COLUMN reminder_time TIME NOT NULL DEFAULT '18:00:00' AFTER browser_reminders_enabled"
    );

    ensureColumnExists(
        $connection,
        'users',
        'planner_weight',
        "ALTER TABLE users ADD COLUMN planner_weight INT NOT NULL DEFAULT 10 AFTER reminder_time"
    );

    ensureColumnExists(
        $connection,
        'users',
        'max_hours_per_subject',
        "ALTER TABLE users ADD COLUMN max_hours_per_subject DECIMAL(4,1) NOT NULL DEFAULT 4.0 AFTER planner_weight"
    );

    ensureColumnExists(
        $connection,
        'subjects',
        'subject_notes',
        "ALTER TABLE subjects ADD COLUMN subject_notes TEXT NULL AFTER exam_date"
    );

    $hasRun = true;
}

function ensureColumnExists(mysqli $connection, string $table, string $column, string $alterQuery): void
{
    $safeTable = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $safeColumn = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    $result = $connection->query("SHOW COLUMNS FROM `{$safeTable}` LIKE '{$safeColumn}'");

    if ($result->num_rows === 0) {
        $connection->query($alterQuery);
    }
}

function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function url(string $path = ''): string
{
    $baseUrl = APP_BASE_URL === '/' ? '' : APP_BASE_URL;
    return $baseUrl . $path;
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

function addFlashMessage(string $type, string $message): void
{
    $_SESSION['flash_messages'][] = [
        'type' => $type,
        'message' => $message,
    ];
}

function consumeFlashMessages(): array
{
    $messages = $_SESSION['flash_messages'] ?? [];
    $_SESSION['flash_messages'] = [];
    return $messages;
}

function bindStatementParameters(mysqli_stmt $statement, string $types, array $params): void
{
    if ($types === '' || empty($params)) {
        return;
    }

    $references = [];

    foreach ($params as $index => $value) {
        $references[$index] = &$params[$index];
    }

    array_unshift($references, $types);
    call_user_func_array([$statement, 'bind_param'], $references);
}

function dbFetchAll(string $sql, string $types = '', array $params = []): array
{
    $statement = getDbConnection()->prepare($sql);
    bindStatementParameters($statement, $types, $params);
    $statement->execute();

    $result = $statement->get_result();
    $rows = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

    $statement->close();

    return $rows;
}

function dbFetchOne(string $sql, string $types = '', array $params = []): ?array
{
    $rows = dbFetchAll($sql, $types, $params);
    return $rows[0] ?? null;
}

function dbExecute(string $sql, string $types = '', array $params = []): array
{
    $statement = getDbConnection()->prepare($sql);
    bindStatementParameters($statement, $types, $params);
    $statement->execute();

    $result = [
        'affected_rows' => $statement->affected_rows,
        'insert_id' => getDbConnection()->insert_id,
    ];

    $statement->close();

    return $result;
}

function getCurrentUserId(): ?int
{
    return isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null;
}

function isLoggedIn(): bool
{
    return getCurrentUserId() !== null;
}

function requireLogin(): void
{
    if (!isLoggedIn()) {
        addFlashMessage('warning', 'Please log in to continue.');
        redirect('/pages/login.php');
    }
}

function getCurrentUser(): ?array
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return null;
    }

    $user = dbFetchOne("SELECT * FROM users WHERE id = ?", 'i', [$userId]);

    if ($user === null) {
        unset($_SESSION['user_id']);
        return null;
    }

    return normalizeUserRecord($user);
}

function normalizeUserRecord(array $user): array
{
    $user['id'] = (int) $user['id'];
    $user['daily_study_hours'] = (float) ($user['daily_study_hours'] ?? DEFAULT_DAILY_HOURS);
    $user['browser_reminders_enabled'] = (bool) ($user['browser_reminders_enabled'] ?? false);
    $user['reminder_time'] = substr((string) ($user['reminder_time'] ?? DEFAULT_REMINDER_TIME), 0, 5);
    $user['planner_weight'] = (int) ($user['planner_weight'] ?? APP_WEIGHT);
    $user['max_hours_per_subject'] = (float) ($user['max_hours_per_subject'] ?? 4.0);

    return $user;
}

function findUserByEmail(string $email): ?array
{
    $user = dbFetchOne("SELECT * FROM users WHERE email = ?", 's', [$email]);
    return $user ? normalizeUserRecord($user) : null;
}

function createUser(string $fullName, string $email, string $password): int
{
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $result = dbExecute(
        "INSERT INTO users (full_name, email, password_hash, daily_study_hours, browser_reminders_enabled, reminder_time, planner_weight, max_hours_per_subject)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        'sssdisid',
        [$fullName, $email, $hash, DEFAULT_DAILY_HOURS, 0, DEFAULT_REMINDER_TIME, APP_WEIGHT, 4.0]
    );

    if (session_status() === PHP_SESSION_ACTIVE || (function_exists('session_status') && session_status() === PHP_SESSION_ACTIVE)) {
        session_regenerate_id(true);
    }

    return (int) $result['insert_id'];
}

function attemptLogin(string $email, string $password): bool
{
    $user = findUserByEmail($email);

    if ($user === null) {
        return false;
    }

    if (!password_verify($password, $user['password_hash'])) {
        return false;
    }

    if (session_status() === PHP_SESSION_ACTIVE || (function_exists('session_status') && session_status() === PHP_SESSION_ACTIVE)) {
        session_regenerate_id(true);
    }

    $_SESSION['user_id'] = (int) $user['id'];
    return true;
}

function logoutCurrentUser(): void
{
    unset($_SESSION['user_id']);
}

function getUserFirstName(): string
{
    $user = getCurrentUser();

    if ($user === null) {
        return 'Guest';
    }

    $parts = preg_split('/\s+/', trim($user['full_name']));
    return $parts[0] ?? $user['full_name'];
}

function normalizeDifficulty(string $difficulty): string
{
    $difficulty = strtolower(trim($difficulty));
    $allowed = ['easy', 'medium', 'hard'];

    if (!in_array($difficulty, $allowed, true)) {
        return 'medium';
    }

    return $difficulty;
}

function difficultyToNumber(string $difficulty): int
{
    $difficulty = normalizeDifficulty($difficulty);

    if ($difficulty === 'easy') {
        return 1;
    }

    if ($difficulty === 'hard') {
        return 3;
    }

    return 2;
}

function difficultyToLabel(string $difficulty): string
{
    return ucfirst(normalizeDifficulty($difficulty));
}

function getDailyHours(): float
{
    $user = getCurrentUser();
    return $user ? (float) $user['daily_study_hours'] : DEFAULT_DAILY_HOURS;
}

function getReminderSettings(): array
{
    $user = getCurrentUser();

    return [
        'browser_enabled' => $user ? (bool) $user['browser_reminders_enabled'] : false,
        'reminder_time' => $user ? $user['reminder_time'] : substr(DEFAULT_REMINDER_TIME, 0, 5),
    ];
}

function normalizeReminderTime(string $time): string
{
    $time = trim($time);

    if (preg_match('/^\d{2}:\d{2}$/', $time) === 1) {
        return $time . ':00';
    }

    if (preg_match('/^\d{2}:\d{2}:\d{2}$/', $time) === 1) {
        return $time;
    }

    return DEFAULT_REMINDER_TIME;
}

function saveUserSettings(float $dailyHours, bool $browserRemindersEnabled, string $reminderTime, int $plannerWeight = 10, float $maxHours = 4.0): void
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return;
    }

    dbExecute(
        "UPDATE users
         SET daily_study_hours = ?, browser_reminders_enabled = ?, reminder_time = ?, planner_weight = ?, max_hours_per_subject = ?
         WHERE id = ?",
         'disidi',
        [$dailyHours, $browserRemindersEnabled ? 1 : 0, normalizeReminderTime($reminderTime), $plannerWeight, $maxHours, $userId]
    );

    if (!empty(getSubjects())) {
        generateAndSavePlanForCurrentUser();
    } else {
        clearStudyPlanForCurrentUser();
    }
}

function getSubjects(): array
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return [];
    }

    $subjects = dbFetchAll(
        "SELECT id, subject_name AS name, difficulty, difficulty_value, exam_date, subject_notes, created_at
         FROM subjects
         WHERE user_id = ?
         ORDER BY exam_date ASC, subject_name ASC",
        'i',
        [$userId]
    );

    foreach ($subjects as &$subject) {
        $subject = normalizeSubjectRecord($subject);
    }

    return $subjects;
}

function normalizeSubjectRecord(array $subject): array
{
    $subject['id'] = (int) $subject['id'];
    $subject['difficulty'] = normalizeDifficulty($subject['difficulty']);
    $subject['difficulty_value'] = (int) ($subject['difficulty_value'] ?? difficultyToNumber($subject['difficulty']));
    $subject['subject_notes'] = $subject['subject_notes'] !== null ? (string) $subject['subject_notes'] : '';
    return $subject;
}

function getSubjectById(int $subjectId): ?array
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return null;
    }

    $subject = dbFetchOne(
        "SELECT id, subject_name AS name, difficulty, difficulty_value, exam_date, subject_notes, created_at
         FROM subjects
         WHERE id = ? AND user_id = ?",
        'ii',
        [$subjectId, $userId]
    );

    return $subject ? normalizeSubjectRecord($subject) : null;
}

function addSubjectToStore(array $subject): void
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return;
    }

    $difficulty = normalizeDifficulty($subject['difficulty']);
    $notes = isset($subject['subject_notes']) ? trim($subject['subject_notes']) : null;

    dbExecute(
        "INSERT INTO subjects (user_id, subject_name, difficulty, difficulty_value, exam_date, subject_notes)
         VALUES (?, ?, ?, ?, ?, ?)",
        'ississ',
        [
            $userId,
            trim($subject['name']),
            $difficulty,
            difficultyToNumber($difficulty),
            $subject['exam_date'],
            $notes !== '' ? $notes : null,
        ]
    );

    refreshPlanAfterSubjectChange();
}

function updateSubjectRecord(int $subjectId, array $subject): bool
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return false;
    }

    $difficulty = normalizeDifficulty($subject['difficulty']);
    $notes = isset($subject['subject_notes']) ? trim($subject['subject_notes']) : null;

    $result = dbExecute(
        "UPDATE subjects
         SET subject_name = ?, difficulty = ?, difficulty_value = ?, exam_date = ?, subject_notes = ?
         WHERE id = ? AND user_id = ?",
        'ssissii',
        [
            trim($subject['name']),
            $difficulty,
            difficultyToNumber($difficulty),
            $subject['exam_date'],
            $notes !== '' ? $notes : null,
            $subjectId,
            $userId,
        ]
    );

    refreshPlanAfterSubjectChange();

    return $result['affected_rows'] >= 0;
}

function deleteSubjectRecord(int $subjectId): bool
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return false;
    }

    $result = dbExecute(
        "DELETE FROM subjects WHERE id = ? AND user_id = ?",
        'ii',
        [$subjectId, $userId]
    );

    refreshPlanAfterSubjectChange();

    return $result['affected_rows'] > 0;
}

function refreshPlanAfterSubjectChange(): void
{
    if (!empty(getSubjects()) && getDailyHours() > 0) {
        generateAndSavePlanForCurrentUser();
        return;
    }

    clearStudyPlanForCurrentUser();
}

function getStudyPlan(): array
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return [];
    }

    $studyPlan = dbFetchAll(
        "SELECT
            sp.id,
            sp.subject_id,
            s.subject_name AS subject_name,
            s.difficulty,
            s.exam_date,
            s.subject_notes AS subject_notes,
            sp.plan_date AS date,
            sp.days_left,
            sp.priority_score,
            sp.recommended_hours,
            sp.status
         FROM study_plan sp
         INNER JOIN subjects s ON s.id = sp.subject_id
         WHERE sp.user_id = ?
         ORDER BY sp.plan_date ASC, sp.priority_score DESC, s.subject_name ASC",
        'i',
        [$userId]
    );

    foreach ($studyPlan as &$planItem) {
        $planItem['id'] = (int) $planItem['id'];
        $planItem['subject_id'] = (int) $planItem['subject_id'];
        $planItem['days_left'] = (int) $planItem['days_left'];
        $planItem['priority_score'] = (float) $planItem['priority_score'];
        $planItem['recommended_hours'] = (float) $planItem['recommended_hours'];
        $planItem['difficulty'] = normalizeDifficulty($planItem['difficulty']);
        $planItem['subject_notes'] = $planItem['subject_notes'] !== null ? (string) $planItem['subject_notes'] : '';
    }

    return $studyPlan;
}

function clearStudyPlanForCurrentUser(): void
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return;
    }

    dbExecute("DELETE FROM study_plan WHERE user_id = ?", 'i', [$userId]);
}

function replaceStudyPlan(array $studyPlan): void
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return;
    }

    $connection = getDbConnection();
    $connection->begin_transaction();

    try {
        $deleteStatement = $connection->prepare("DELETE FROM study_plan WHERE user_id = ?");
        $deleteStatement->bind_param('i', $userId);
        $deleteStatement->execute();
        $deleteStatement->close();

        if (!empty($studyPlan)) {
            $insertStatement = $connection->prepare(
                "INSERT INTO study_plan
                    (user_id, subject_id, plan_date, days_left, priority_score, recommended_hours, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );

            foreach ($studyPlan as $planItem) {
                $subjectId = (int) $planItem['subject_id'];
                $planDate = $planItem['date'];
                $daysLeft = (int) $planItem['days_left'];
                $priorityScore = (float) $planItem['priority_score'];
                $recommendedHours = (float) $planItem['recommended_hours'];
                $status = $planItem['status'];

                $insertStatement->bind_param(
                    'iisidds',
                    $userId,
                    $subjectId,
                    $planDate,
                    $daysLeft,
                    $priorityScore,
                    $recommendedHours,
                    $status
                );

                $insertStatement->execute();
            }

            $insertStatement->close();
        }

        $connection->commit();
    } catch (Throwable $exception) {
        $connection->rollback();
        throw $exception;
    }
}

function calculateDaysLeft(string $examDate, ?DateTime $referenceDate = null): int
{
    $today = $referenceDate ? clone $referenceDate : new DateTime('today');
    $today->setTime(0, 0, 0);

    $exam = new DateTime($examDate);
    $exam->setTime(0, 0, 0);

    $differenceInSeconds = $exam->getTimestamp() - $today->getTimestamp();

    if ($differenceInSeconds < 0) {
        return 0;
    }

    if ($differenceInSeconds === 0) {
        return 1;
    }

    return (int) ceil($differenceInSeconds / 86400);
}

function calculatePriorityScore(string $difficulty, int $daysLeft, int $weight = APP_WEIGHT): float
{
    if ($daysLeft <= 0) {
        return 0;
    }

    return round((difficultyToNumber($difficulty) * $weight) / $daysLeft, 2);
}

function formatFriendlyDate(string $date): string
{
    return date('M d, Y', strtotime($date));
}

function formatHours(float $hours): string
{
    return number_format($hours, 1);
}

function generateStudyPlanData(array $subjects, float $dailyHours, int $weight = APP_WEIGHT, array $existingPlan = [], float $maxHoursPerSubject = 4.0): array
{
    if (empty($subjects) || $dailyHours <= 0) {
        return [];
    }

    $today = new DateTime('today');
    $upcomingSubjects = [];

    foreach ($subjects as $subject) {
        $examDate = new DateTime($subject['exam_date']);

        if ($examDate >= $today) {
            $upcomingSubjects[] = $subject;
        }
    }

    if (empty($upcomingSubjects)) {
        return [];
    }

    $statusMap = [];

    foreach ($existingPlan as $planItem) {
        $statusMap[$planItem['subject_id'] . '|' . $planItem['date']] = $planItem['status'];
    }

    $latestExamTimestamp = max(array_map(function (array $subject): int {
        return strtotime($subject['exam_date']);
    }, $upcomingSubjects));

    $finalDate = new DateTime(date('Y-m-d', $latestExamTimestamp));
    $cursor = clone $today;
    $generatedPlan = [];

    while ($cursor <= $finalDate) {
        $activeSubjects = [];

        foreach ($upcomingSubjects as $subject) {
            $examDate = new DateTime($subject['exam_date']);

            if ($cursor > $examDate) {
                continue;
            }

            $daysLeft = calculateDaysLeft($subject['exam_date'], $cursor);
            $priorityScore = calculatePriorityScore($subject['difficulty'], $daysLeft, $weight);

            $activeSubjects[] = [
                'subject' => $subject,
                'days_left' => $daysLeft,
                'priority_score' => $priorityScore,
            ];
        }

        if (!empty($activeSubjects)) {
            usort($activeSubjects, function (array $first, array $second): int {
                return $second['priority_score'] <=> $first['priority_score'];
            });

            // Proportional distribution with cap algorithm
            $allocated = [];
            $uncappedSubjects = [];
            foreach ($activeSubjects as $activeSubject) {
                $uncappedSubjects[] = $activeSubject;
            }
            $remainingHours = $dailyHours;

            while (!empty($uncappedSubjects) && $remainingHours > 0.01) {
                $totalPriority = array_sum(array_map(function($s) { return $s['priority_score']; }, $uncappedSubjects));
                $nextUncapped = [];
                $allocatedThisRound = false;

                foreach ($uncappedSubjects as $activeSubject) {
                    $subId = (int)$activeSubject['subject']['id'];
                    $currentAllocated = $allocated[$subId] ?? 0.0;

                    if ($totalPriority <= 0) {
                        $share = $remainingHours / count($uncappedSubjects);
                    } else {
                        $share = $remainingHours * ($activeSubject['priority_score'] / $totalPriority);
                    }

                    $newAllocated = $currentAllocated + $share;
                    if ($newAllocated > $maxHoursPerSubject) {
                        $allocated[$subId] = $maxHoursPerSubject;
                        $remainingHours -= ($maxHoursPerSubject - $currentAllocated);
                        $allocatedThisRound = true;
                    } else {
                        $nextUncapped[] = $activeSubject;
                    }
                }

                if (!$allocatedThisRound) {
                    // No one was capped this round, allocate the rest proportionally and break
                    foreach ($uncappedSubjects as $activeSubject) {
                        $subId = (int)$activeSubject['subject']['id'];
                        $currentAllocated = $allocated[$subId] ?? 0.0;
                        if ($totalPriority <= 0) {
                            $share = $remainingHours / count($uncappedSubjects);
                        } else {
                            $share = $remainingHours * ($activeSubject['priority_score'] / $totalPriority);
                        }
                        $allocated[$subId] = round($currentAllocated + $share, 2);
                    }
                    break;
                }

                $uncappedSubjects = $nextUncapped;
            }

            foreach ($activeSubjects as $activeSubject) {
                $subId = (int) $activeSubject['subject']['id'];
                $recommendedHours = $allocated[$subId] ?? 0.0;

                if ($recommendedHours <= 0) {
                    continue;
                }

                $date = $cursor->format('Y-m-d');
                $statusKey = $subId . '|' . $date;

                $generatedPlan[] = [
                    'date' => $date,
                    'subject_id' => $subId,
                    'subject_name' => $activeSubject['subject']['name'],
                    'difficulty' => $activeSubject['subject']['difficulty'],
                    'exam_date' => $activeSubject['subject']['exam_date'],
                    'days_left' => $activeSubject['days_left'],
                    'priority_score' => $activeSubject['priority_score'],
                    'recommended_hours' => $recommendedHours,
                    'status' => $statusMap[$statusKey] ?? 'pending',
                ];
            }
        }

        $cursor->modify('+1 day');
    }

    return $generatedPlan;
}

function generateAndSavePlanForCurrentUser(): array
{
    $user = getCurrentUser();
    $weight = $user ? (int) $user['planner_weight'] : APP_WEIGHT;
    $maxHours = $user ? (float) $user['max_hours_per_subject'] : 4.0;

    $plan = generateStudyPlanData(getSubjects(), getDailyHours(), $weight, getStudyPlan(), $maxHours);
    replaceStudyPlan($plan);
    return getStudyPlan();
}

function groupPlanByDate(array $studyPlan): array
{
    $grouped = [];

    foreach ($studyPlan as $planItem) {
        $grouped[$planItem['date']][] = $planItem;
    }

    ksort($grouped);

    return $grouped;
}

function updateStudyPlanStatus(int $planId, string $status): bool
{
    $userId = getCurrentUserId();

    if ($userId === null) {
        return false;
    }

    $safeStatus = $status === 'completed' ? 'completed' : 'pending';

    $result = dbExecute(
        "UPDATE study_plan SET status = ? WHERE id = ? AND user_id = ?",
        'sii',
        [$safeStatus, $planId, $userId]
    );

    return $result['affected_rows'] > 0;
}

function getSubjectProgressSummary(array $subject, array $studyPlan): array
{
    $subjectPlan = array_values(array_filter($studyPlan, function (array $planItem) use ($subject): bool {
        return $planItem['subject_id'] === $subject['id'];
    }));

    $totalHours = 0.0;
    $completedHours = 0.0;
    $completedTasks = 0;

    foreach ($subjectPlan as $planItem) {
        $totalHours += (float) $planItem['recommended_hours'];

        if ($planItem['status'] === 'completed') {
            $completedHours += (float) $planItem['recommended_hours'];
            $completedTasks++;
        }
    }

    $progressPercentage = $totalHours > 0 ? (int) round(($completedHours / $totalHours) * 100) : 0;

    return [
        'total_tasks' => count($subjectPlan),
        'completed_tasks' => $completedTasks,
        'planned_hours' => $totalHours,
        'completed_hours' => $completedHours,
        'remaining_hours' => max($totalHours - $completedHours, 0),
        'progress_percentage' => $progressPercentage,
    ];
}

function getOverallProgress(array $studyPlan): int
{
    $plannedHours = 0.0;
    $completedHours = 0.0;

    foreach ($studyPlan as $planItem) {
        $plannedHours += (float) $planItem['recommended_hours'];

        if ($planItem['status'] === 'completed') {
            $completedHours += (float) $planItem['recommended_hours'];
        }
    }

    if ($plannedHours <= 0) {
        return 0;
    }

    return (int) round(($completedHours / $plannedHours) * 100);
}

function buildSubjectCards(array $subjects, array $studyPlan): array
{
    $subjectCards = [];

    foreach ($subjects as $subject) {
        $daysLeft = calculateDaysLeft($subject['exam_date']);
        $progress = getSubjectProgressSummary($subject, $studyPlan);

        $subjectCards[] = array_merge($subject, [
            'difficulty_value' => difficultyToNumber($subject['difficulty']),
            'difficulty_label' => difficultyToLabel($subject['difficulty']),
            'days_left' => $daysLeft,
            'priority_score' => $daysLeft > 0 ? calculatePriorityScore($subject['difficulty'], $daysLeft, APP_WEIGHT) : 0,
            'progress' => $progress,
        ]);
    }

    usort($subjectCards, function (array $first, array $second): int {
        return $second['priority_score'] <=> $first['priority_score'];
    });

    return $subjectCards;
}

function buildDashboardAlerts(array $subjects, array $studyPlan, float $dailyHours): array
{
    $alerts = [];

    if (empty($subjects)) {
        $alerts[] = [
            'type' => 'info',
            'message' => 'Add your first subject to start building a plan.',
        ];
    }

    if ($dailyHours <= 0) {
        $alerts[] = [
            'type' => 'warning',
            'message' => 'Daily study hours are set to 0.',
        ];
    }

    if (!empty($subjects) && empty($studyPlan)) {
        $alerts[] = [
            'type' => 'info',
            'message' => 'Your plan is empty. Generate a new schedule.',
        ];
    }

    // Check for exam date collisions (multiple exams on the same day)
    $dates = [];
    foreach ($subjects as $subject) {
        $dates[$subject['exam_date']][] = $subject['name'];
    }
    foreach ($dates as $date => $subNames) {
        if (count($subNames) > 1) {
            $alerts[] = [
                'type' => 'warning',
                'message' => 'Multiple exams scheduled on ' . formatFriendlyDate($date) . ' (' . implode(', ', $subNames) . '). Collision warning!',
            ];
        }
    }

    foreach (buildSubjectCards($subjects, $studyPlan) as $subject) {
        if ($subject['days_left'] > 0 && $subject['days_left'] <= 3) {
            $alerts[] = [
                'type' => 'warning',
                'message' => $subject['name'] . ' exam is in ' . $subject['days_left'] . ' day(s).',
            ];
        }

        if ($subject['days_left'] === 0) {
            $alerts[] = [
                'type' => 'danger',
                'message' => $subject['name'] . ' has a past exam date.',
            ];
        }

        if ($subject['days_left'] > 0 && $subject['days_left'] <= 5 && $subject['progress']['progress_percentage'] < 40) {
            $alerts[] = [
                'type' => 'danger',
                'message' => $subject['name'] . ' needs attention soon.',
            ];
        }
    }

    return $alerts;
}

function getNextStudySession(array $studyPlan): ?array
{
    $today = date('Y-m-d');

    foreach ($studyPlan as $planItem) {
        if ($planItem['status'] === 'pending' && $planItem['date'] >= $today) {
            return $planItem;
        }
    }

    return null;
}

function countPlannedDays(array $studyPlan): int
{
    if (empty($studyPlan)) {
        return 0;
    }

    return count(array_unique(array_column($studyPlan, 'date')));
}

function getHighestPriorityTask(array $studyPlan): ?array
{
    if (empty($studyPlan)) {
        return null;
    }

    $sortedPlan = $studyPlan;

    usort($sortedPlan, function (array $first, array $second): int {
        return $second['priority_score'] <=> $first['priority_score'];
    });

    return $sortedPlan[0] ?? null;
}

function buildCalendarMatrix(array $studyPlan, int $month, int $year): array
{
    $groupedPlan = groupPlanByDate($studyPlan);
    $firstOfMonth = new DateTime(sprintf('%04d-%02d-01', $year, $month));
    $lastOfMonth = new DateTime($firstOfMonth->format('Y-m-t'));

    $calendarStart = clone $firstOfMonth;
    $calendarStart->modify('-' . ((int) $firstOfMonth->format('N') - 1) . ' days');

    $calendarEnd = clone $lastOfMonth;
    $calendarEnd->modify('+' . (7 - (int) $lastOfMonth->format('N')) . ' days');

    $weeks = [];
    $currentWeek = [];
    $cursor = clone $calendarStart;

    while ($cursor <= $calendarEnd) {
        $date = $cursor->format('Y-m-d');
        $tasks = $groupedPlan[$date] ?? [];

        $currentWeek[] = [
            'date' => $date,
            'day_number' => (int) $cursor->format('j'),
            'is_current_month' => (int) $cursor->format('n') === $month,
            'is_today' => $date === date('Y-m-d'),
            'tasks' => $tasks,
            'total_hours' => array_sum(array_column($tasks, 'recommended_hours')),
        ];

        if (count($currentWeek) === 7) {
            $weeks[] = $currentWeek;
            $currentWeek = [];
        }

        $cursor->modify('+1 day');
    }

    return $weeks;
}

function buildReminderPayload(array $studyPlan, array $subjectCards): array
{
    $today = date('Y-m-d');
    $reminderSettings = getReminderSettings();
    $todayTasks = array_values(array_filter($studyPlan, function (array $planItem) use ($today): bool {
        return $planItem['date'] === $today && $planItem['status'] === 'pending';
    }));

    $urgentSubjects = array_values(array_filter($subjectCards, function (array $subject): bool {
        return $subject['days_left'] > 0 && $subject['days_left'] <= 2;
    }));

    return [
        'enabled' => $reminderSettings['browser_enabled'],
        'reminder_time' => $reminderSettings['reminder_time'],
        'user_id' => getCurrentUserId(),
        'today_tasks' => array_map(function (array $task): array {
            return [
                'subject_name' => $task['subject_name'],
                'recommended_hours' => formatHours((float) $task['recommended_hours']),
                'priority_score' => number_format((float) $task['priority_score'], 2),
            ];
        }, $todayTasks),
        'urgent_subjects' => array_map(function (array $subject): array {
            return [
                'name' => $subject['name'],
                'days_left' => $subject['days_left'],
            ];
        }, $urgentSubjects),
    ];
}

function jsonForAttribute($value): string
{
    return htmlspecialchars(json_encode($value), ENT_QUOTES, 'UTF-8');
}

function isActivePage(string $fileName): bool
{
    $currentPath = basename($_SERVER['PHP_SELF'] ?? '');
    return $currentPath === $fileName;
}

function generateCsrfToken(): string
{
    if (!isset($_SESSION['csrf_token']) || empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validateCsrfToken(?string $token): bool
{
    if (!isset($_SESSION['csrf_token']) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], (string) $token);
}

function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(generateCsrfToken()) . '">';
}
