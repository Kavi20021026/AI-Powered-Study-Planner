<?php
/**
 * includes/header.php
 *
 * Shared page shell and navigation.
 */

$pageTitle = $pageTitle ?? APP_NAME;
$pageHeading = $pageHeading ?? APP_NAME;
$pageDescription = $pageDescription ?? 'Plan smarter, stay focused, and track your progress clearly.';
$heroEyebrow = $heroEyebrow ?? 'AI Study Planner';
$showPageHero = $showPageHero ?? true;
$flashMessages = consumeFlashMessages();
$isAuthenticated = isLoggedIn();
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(url('/css/style.css?v=1.1')) ?>">
</head>
<body>
    <div class="background-orb orb-one"></div>
    <div class="background-orb orb-two"></div>

    <header class="topbar">
        <div class="brand-block">
            <a class="brand" href="<?= e($isAuthenticated ? url('/index.php') : url('/pages/login.php')) ?>">Study Planner</a>
            <p class="brand-subtitle">Prioritized plans, clear progress</p>
        </div>

        <div class="topbar-tools">
            <?php if ($isAuthenticated): ?>
                <span class="user-chip">Hi, <?= e(getUserFirstName()) ?></span>
            <?php endif; ?>

            <button
                class="menu-toggle"
                type="button"
                data-nav-toggle
                aria-expanded="false"
                aria-controls="main-navigation"
                aria-label="Toggle navigation"
            >
                <span></span>
                <span></span>
                <span></span>
                <span class="sr-only">Toggle navigation</span>
            </button>

            <button class="theme-toggle" type="button" data-theme-toggle aria-label="Toggle dark mode">
                <span data-theme-label>Dark mode</span>
            </button>
        </div>

        <nav class="nav-links" id="main-navigation" aria-label="Main navigation">
            <?php if ($isAuthenticated): ?>
                <a class="<?= isActivePage('index.php') ? 'is-active' : '' ?>" href="<?= e(url('/index.php')) ?>">Dashboard</a>
                <a class="<?= isActivePage('add_subject.php') ? 'is-active' : '' ?>" href="<?= e(url('/pages/add_subject.php')) ?>">Add Subject</a>
                <a class="<?= isActivePage('generate_plan.php') ? 'is-active' : '' ?>" href="<?= e(url('/pages/generate_plan.php')) ?>">Generate Plan</a>
                <a class="<?= isActivePage('view_plan.php') ? 'is-active' : '' ?>" href="<?= e(url('/pages/view_plan.php')) ?>">View Plan</a>
                <a class="<?= isActivePage('calendar.php') ? 'is-active' : '' ?>" href="<?= e(url('/pages/calendar.php')) ?>">Calendar</a>
                <a class="<?= isActivePage('progress.php') ? 'is-active' : '' ?>" href="<?= e(url('/pages/progress.php')) ?>">Progress</a>
                <a href="<?= e(url('/pages/logout.php')) ?>">Logout</a>
            <?php else: ?>
                <a class="<?= isActivePage('login.php') ? 'is-active' : '' ?>" href="<?= e(url('/pages/login.php')) ?>">Login</a>
                <a class="<?= isActivePage('register.php') ? 'is-active' : '' ?>" href="<?= e(url('/pages/register.php')) ?>">Register</a>
            <?php endif; ?>
        </nav>
    </header>

    <main class="app-shell">
        <?php if ($showPageHero): ?>
            <section class="hero-card">
                <div>
                    <p class="eyebrow"><?= e($heroEyebrow) ?></p>
                    <h1><?= e($pageHeading) ?></h1>
                    <p><?= e($pageDescription) ?></p>
                </div>
                <div class="hero-actions">
                    <?php if ($isAuthenticated): ?>
                        <a class="button" href="<?= e(url('/pages/add_subject.php')) ?>">Add Subject</a>
                        <a class="button button-secondary" href="<?= e(url('/pages/calendar.php')) ?>">Calendar</a>
                    <?php else: ?>
                        <a class="button" href="<?= e(url('/pages/register.php')) ?>">Create Account</a>
                        <a class="button button-secondary" href="<?= e(url('/pages/login.php')) ?>">Login</a>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php foreach ($flashMessages as $flashMessage): ?>
            <div class="flash flash-<?= e($flashMessage['type']) ?>" data-auto-dismiss="true">
                <span><?= e($flashMessage['message']) ?></span>
                <button type="button" class="flash-close" data-close-flash aria-label="Close message">&times;</button>
            </div>
        <?php endforeach; ?>
