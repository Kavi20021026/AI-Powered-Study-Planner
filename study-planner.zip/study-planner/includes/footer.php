<?php
/**
 * includes/footer.php
 *
 * Shared footer and JavaScript include.
 * Every page closes its layout by including this file.
 */
?>
    </main>

    <footer class="footer">
        <p>AI-powered planning, progress tracking, and a clean daily schedule.</p>
    </footer>

    <script src="<?= e(url('/js/app.js?v=1.2')) ?>"></script>
</body>
</html>
